package com.puspo.authZ.service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface RoleAssignmentService {
    Flux<String> rolesForSubject(UUID subjectId, String subjectType);
    Mono<Boolean> assignRole(UUID subjectId, String subjectType, String roleCode, UUID assignedBy);
}