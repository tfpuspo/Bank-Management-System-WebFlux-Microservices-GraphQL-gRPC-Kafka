package com.puspo.authZ.serviceImpl;

import com.puspo.authZ.entity.Alkp;
import com.puspo.authZ.entity.RolePermission;
import com.puspo.authZ.repository.AlkpRepository;
import com.puspo.authZ.repository.RolePermissionRepository;
import com.puspo.authZ.service.RoleAssignmentService;
import com.puspo.authZ.service.RolePermissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RolePermissionServiceImpl implements RolePermissionService {

    private final AlkpRepository alkpRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final RoleAssignmentService roleAssignmentService;

    @Override
    public Mono<Boolean> assignPermissionToRole(String roleCode, String permissionCode, UUID grantedBy) {
        Mono<Alkp> roleMono = alkpRepository.findByType("ROLE")
                .filter(r -> r.getLabel().equalsIgnoreCase(roleCode))
                .next()
                .switchIfEmpty(Mono.error(new RuntimeException("Unknown role: " + roleCode)));

        Mono<Alkp> permissionMono = alkpRepository.findByType("PERMISSION")
                .filter(p -> p.getLabel().equalsIgnoreCase(permissionCode))
                .next()
                .switchIfEmpty(Mono.error(new RuntimeException("Unknown permission: " + permissionCode)));

        return Mono.zip(roleMono, permissionMono)
                .flatMap(tuple -> {
                    UUID roleId = tuple.getT1().getId();
                    UUID permissionId = tuple.getT2().getId();

                    return rolePermissionRepository.existsByRoleIdAndPermissionId(roleId, permissionId)
                            .flatMap(alreadyGranted -> {
                                if (Boolean.TRUE.equals(alreadyGranted)) {
                                    // Idempotent — granting the same permission twice is a no-op, not an error.
                                    return Mono.just(true);
                                }
                                RolePermission rp = new RolePermission();
                                rp.setRoleId(roleId);
                                rp.setPermissionId(permissionId);
                                rp.setGrantedBy(grantedBy);
                                rp.setGrantedAt(LocalDateTime.now());
                                return rolePermissionRepository.save(rp).thenReturn(true);
                            });
                });
    }

    @Override
    public Flux<String> permissionsForRole(String roleCode) {
        return alkpRepository.findByType("ROLE")
                .filter(r -> r.getLabel().equalsIgnoreCase(roleCode))
                .next()
                .switchIfEmpty(Mono.error(new RuntimeException("Unknown role: " + roleCode)))
                .flatMapMany(role -> rolePermissionRepository.findByRoleId(role.getId()))
                .flatMap(rp -> alkpRepository.findById(rp.getPermissionId()))
                .map(Alkp::getLabel);
    }

    @Override
    public Flux<String> permissionsForSubject(UUID subjectId, String subjectType) {
        // A subject can hold several roles — union the permissions of all of them,
        // deduplicated, so a permission granted via any one role is enough.
        return roleAssignmentService.rolesForSubject(subjectId, subjectType)
                .flatMap(this::permissionsForRole)
                .distinct();
    }
}