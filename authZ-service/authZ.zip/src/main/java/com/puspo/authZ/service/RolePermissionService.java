package com.puspo.authZ.service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface RolePermissionService {
    Mono<Boolean> assignPermissionToRole(String roleCode, String permissionCode, UUID grantedBy);
    Flux<String> permissionsForRole(String roleCode);
    Flux<String> permissionsForSubject(UUID subjectId, String subjectType);
}