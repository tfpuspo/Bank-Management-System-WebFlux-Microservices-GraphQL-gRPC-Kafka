package com.puspo.account.resolver;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsMutation;
import com.netflix.graphql.dgs.DgsQuery;
import com.netflix.graphql.dgs.InputArgument;
import com.puspo.account.client.AuthZServiceClient;
import com.puspo.account.dto.account.AccountResponse;
import com.puspo.account.dto.account.CreateAccountRequest;
import com.puspo.account.security.AuthenticatedPrincipal;
import com.puspo.account.service.AccountService;
import graphql.schema.DataFetchingEnvironment;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@DgsComponent
@RequiredArgsConstructor
public class AccountResolver {

    private final AccountService accountService;
    private final AuthZServiceClient authZServiceClient;

    @DgsQuery
    public Mono<AccountResponse> accountByNumber(@InputArgument("accountNumber") String accountNumber) {
        return accountService.getAccountByNumber(accountNumber);
    }

    @DgsMutation
    public Mono<AccountResponse> createAccount(@InputArgument("input") CreateAccountRequest input,
                                               DataFetchingEnvironment dfe) {
        AuthenticatedPrincipal principal = dfe.getGraphQlContext().get("principal");
        if (principal == null) {
            return Mono.error(new RuntimeException("Not authenticated"));
        }
        return authZServiceClient.hasPermission(principal.subjectId(), principal.subjectType(), "ACCOUNT_OPEN")
                .flatMap(allowed -> {
                    if (!Boolean.TRUE.equals(allowed)) {
                        return Mono.error(new RuntimeException("Forbidden: ACCOUNT_OPEN permission required"));
                    }
                    return accountService.createAccount(input);
                });
    }
}