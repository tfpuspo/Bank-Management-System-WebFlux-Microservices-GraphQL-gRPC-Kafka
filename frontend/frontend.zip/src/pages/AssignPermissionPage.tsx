import { FormEvent, useState } from 'react'
import { assignPermissionToRole } from '@/services/roleService'
import type { MenuComponentProps } from '@/types/menu'

export default function AssignPermissionPage({}: MenuComponentProps) {
  const [roleCode, setRoleCode] = useState('')
  const [permissionCode, setPermissionCode] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setSubmitting(true)
    try {
      await assignPermissionToRole(roleCode.trim(), permissionCode.trim())
      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to assign permission.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <h1 className="text-2xl font-bold text-white">Assign permission to role</h1>
      <p className="mt-1 text-sm text-zinc-400">
        Granting a permission here takes effect for every subject holding this role on their next
        login — no redeploy needed.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-semibold text-zinc-200">Role code</label>
          <input
            type="text"
            value={roleCode}
            onChange={(e) => setRoleCode(e.target.value.toUpperCase())}
            placeholder="TELLER"
            required
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm text-white placeholder-zinc-500 outline-none focus:border-blue-500"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-semibold text-zinc-200">Permission code</label>
          <input
            type="text"
            value={permissionCode}
            onChange={(e) => setPermissionCode(e.target.value.toUpperCase())}
            placeholder="ACCOUNT_VIEW"
            required
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm text-white placeholder-zinc-500 outline-none focus:border-blue-500"
          />
        </div>

        {error && (
          <p className="rounded-lg border border-red-900 bg-red-950/50 px-4 py-2.5 text-sm text-red-400">
            {error}
          </p>
        )}
        {success && (
          <p className="rounded-lg border border-emerald-900 bg-emerald-950/50 px-4 py-2.5 text-sm text-emerald-400">
            Permission granted to role.
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-blue-600 py-2.5 text-sm font-bold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? 'Granting…' : 'Grant permission'}
        </button>
      </form>
    </div>
  )
}
