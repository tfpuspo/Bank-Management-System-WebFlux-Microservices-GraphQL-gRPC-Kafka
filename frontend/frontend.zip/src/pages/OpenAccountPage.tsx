import { FormEvent, useState } from 'react'
import { createCustomer, createAccount } from '@/services/accountOpeningService'
import { assignRole } from '@/services/roleService'
import type { MenuComponentProps } from '@/types/menu'

type StepStatus = 'pending' | 'running' | 'done' | 'failed'

interface StepState {
  status: StepStatus
  error: string | null
}

const initialSteps: Record<'customer' | 'account' | 'role', StepState> = {
  customer: { status: 'pending', error: null },
  account: { status: 'pending', error: null },
  role: { status: 'pending', error: null },
}

function generateAccountNumber() {
  const ts = Date.now().toString().slice(-8)
  const rand = Math.floor(100 + Math.random() * 900)
  return `AC${ts}${rand}`
}

export default function OpenAccountPage({}: MenuComponentProps) {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [dateOfBirth, setDateOfBirth] = useState('')
  const [mobileNumber, setMobileNumber] = useState('')
  const [email, setEmail] = useState('')
  const [nidNumber, setNidNumber] = useState('')

  const [accountType, setAccountType] = useState<'SAVINGS' | 'CURRENT' | 'FIXED_DEPOSIT'>('SAVINGS')
  const [initialDeposit, setInitialDeposit] = useState('0')

  const [roleCode, setRoleCode] = useState<'RC' | 'BC'>('RC')

  const [steps, setSteps] = useState(initialSteps)
  const [submitting, setSubmitting] = useState(false)
  const [resultSummary, setResultSummary] = useState<{
    customerId: string
    accountNumber: string
  } | null>(null)

  const resetSteps = () => setSteps(initialSteps)

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setResultSummary(null)
    resetSteps()

    // Step 1: create customer
    setSteps((s) => ({ ...s, customer: { status: 'running', error: null } }))
    let customerId: string
    try {
      const customer = await createCustomer({
        firstName,
        lastName,
        dateOfBirth,
        mobileNumber,
        email: email || undefined,
        nidNumber,
      })
      customerId = customer.id
      setSteps((s) => ({ ...s, customer: { status: 'done', error: null } }))
    } catch (err) {
      setSteps((s) => ({
        ...s,
        customer: {
          status: 'failed',
          error: err instanceof Error ? err.message : 'Failed to create customer',
        },
      }))
      setSubmitting(false)
      return
    }

    // Step 2: create account
    setSteps((s) => ({ ...s, account: { status: 'running', error: null } }))
    let accountNumber: string
    try {
      accountNumber = generateAccountNumber()
      const account = await createAccount({
        accountNumber,
        customerId,
        accountType,
        initialDeposit: Number(initialDeposit) || 0,
      })
      accountNumber = account.accountNumber
      setSteps((s) => ({ ...s, account: { status: 'done', error: null } }))
    } catch (err) {
      setSteps((s) => ({
        ...s,
        account: {
          status: 'failed',
          error: err instanceof Error ? err.message : 'Failed to create account',
        },
      }))
      setSubmitting(false)
      return
    }

    // Step 3: assign role (issues the customer's login userId)
    setSteps((s) => ({ ...s, role: { status: 'running', error: null } }))
    try {
      await assignRole(customerId, 'CUSTOMER', roleCode)
      setSteps((s) => ({ ...s, role: { status: 'done', error: null } }))
      setResultSummary({ customerId, accountNumber })
    } catch (err) {
      setSteps((s) => ({
        ...s,
        role: {
          status: 'failed',
          error: err instanceof Error ? err.message : 'Failed to assign role',
        },
      }))
    } finally {
      setSubmitting(false)
    }
  }

  const stepLabel = (status: StepStatus) => {
    switch (status) {
      case 'pending':
        return { text: 'Pending', className: 'text-zinc-500' }
      case 'running':
        return { text: 'Running…', className: 'text-blue-400' }
      case 'done':
        return { text: 'Done', className: 'text-green-400' }
      case 'failed':
        return { text: 'Failed', className: 'text-red-400' }
    }
  }

  return (
    <div className="max-w-2xl">
      <h2 className="text-xl font-bold text-white">Open New Account</h2>
      <p className="mt-1 text-sm text-zinc-400">
        Creates the customer, opens their first account, and assigns their role — in that order. If
        a later step fails, earlier steps have already been committed; re-run only the failed step
        rather than resubmitting the whole form.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-6">
        <fieldset className="space-y-3 rounded-xl border border-zinc-800 p-4">
          <legend className="px-1 text-sm font-semibold text-zinc-300">Customer details</legend>
          <div className="grid grid-cols-2 gap-3">
            <input
              required
              placeholder="First name"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
            />
            <input
              required
              placeholder="Last name"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
            />
          </div>
          <input
            required
            type="date"
            value={dateOfBirth}
            onChange={(e) => setDateOfBirth(e.target.value)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          />
          <input
            required
            placeholder="Mobile number (e.g. 01700000000)"
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          />
          <input
            type="email"
            placeholder="Email (optional)"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          />
          <input
            required
            placeholder="NID number"
            value={nidNumber}
            onChange={(e) => setNidNumber(e.target.value)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          />
        </fieldset>

        <fieldset className="space-y-3 rounded-xl border border-zinc-800 p-4">
          <legend className="px-1 text-sm font-semibold text-zinc-300">Initial account</legend>
          <select
            value={accountType}
            onChange={(e) => setAccountType(e.target.value as typeof accountType)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          >
            <option value="SAVINGS">Savings</option>
            <option value="CURRENT">Current</option>
            <option value="FIXED_DEPOSIT">Fixed Deposit</option>
          </select>
          <input
            type="number"
            min="0"
            step="0.01"
            placeholder="Initial deposit"
            value={initialDeposit}
            onChange={(e) => setInitialDeposit(e.target.value)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          />
        </fieldset>

        <fieldset className="space-y-3 rounded-xl border border-zinc-800 p-4">
          <legend className="px-1 text-sm font-semibold text-zinc-300">Customer role</legend>
          <select
            value={roleCode}
            onChange={(e) => setRoleCode(e.target.value as typeof roleCode)}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-white"
          >
            <option value="RC">Retail Customer</option>
            <option value="BC">Business Customer</option>
          </select>
        </fieldset>

        <div className="space-y-2 rounded-xl border border-zinc-800 p-4">
          <p className="text-sm font-semibold text-zinc-300">Progress</p>
          {(['customer', 'account', 'role'] as const).map((key) => {
            const { status, error } = steps[key]
            const { text, className } = stepLabel(status)
            return (
              <div key={key} className="flex items-start justify-between text-sm">
                <span className="capitalize text-zinc-400">
                  {key === 'customer'
                    ? 'Create customer'
                    : key === 'account'
                      ? 'Create account'
                      : 'Assign role'}
                </span>
                <span className={`text-right ${className}`}>
                  {text}
                  {error && <span className="block text-xs text-red-400">{error}</span>}
                </span>
              </div>
            )
          })}
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-blue-600 py-3 text-sm font-bold text-white hover:bg-blue-500 disabled:opacity-50"
        >
          {submitting ? 'Processing…' : 'Open Account'}
        </button>
      </form>

      {resultSummary && (
        <div className="mt-6 rounded-xl border border-green-900 bg-green-950/40 p-4 text-sm text-green-300">
          Account opened. Customer ID: <span className="font-mono">{resultSummary.customerId}</span>
          , Account number: <span className="font-mono">{resultSummary.accountNumber}</span>. The
          customer's login userId has been issued — a password still needs to be set separately
          before they can log in.
        </div>
      )}
    </div>
  )
}
