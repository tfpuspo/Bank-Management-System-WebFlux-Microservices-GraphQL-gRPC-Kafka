import { useState } from 'react'
import OpenAccountPage from '@/pages/OpenAccountPage'
import type { MenuComponentProps } from '@/types/menu'

type TabKey = 'open-account'

interface TabDef {
  key: TabKey
  label: string
  permission: string
}

const TABS: TabDef[] = [
  { key: 'open-account', label: 'Open New Account', permission: 'ACCOUNT_OPEN' },
]

export default function AccountManagementPage({ permissions }: MenuComponentProps) {
  const visibleTabs = TABS.filter((tab) => permissions.includes(tab.permission))
  const [activeTab, setActiveTab] = useState<TabKey | null>(visibleTabs[0]?.key ?? null)

  return (
    <div className="w-full max-w-5xl">
      <h1 className="text-2xl font-bold text-white">Account Management</h1>
      <p className="mt-1 text-sm text-zinc-400">
        Open new accounts and, once built, search and manage existing ones.
      </p>

      <div className="mt-6 rounded-xl border border-zinc-800 p-4">
        <h2 className="text-sm font-semibold text-zinc-300">Account search / list</h2>
        <p className="mt-2 text-sm text-zinc-500">
          Not built yet — it needs a new account-service query (e.g. a paged{' '}
          <code>accountsByCustomer</code> or <code>allAccounts</code>). Open New Account works today
          regardless of this gap.
        </p>
      </div>

      {visibleTabs.length > 0 && (
        <div className="mt-6">
          <div className="flex gap-2 border-b border-zinc-800">
            {visibleTabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                className={`-mb-px border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-white'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="mt-6">
            {activeTab === 'open-account' && <OpenAccountPage permissions={permissions} />}
          </div>
        </div>
      )}

      {visibleTabs.length === 0 && (
        <p className="mt-6 text-sm text-zinc-500">
          You can view this screen but don't hold the Open Account permission yet.
        </p>
      )}
    </div>
  )
}
