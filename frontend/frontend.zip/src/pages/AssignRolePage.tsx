import { FormEvent, useEffect, useMemo, useState } from 'react'
import { assignRole } from '@/services/roleService'
import { fetchAllUsers, type StaffUserResult } from '@/services/staffService'
import type { MenuComponentProps } from '@/types/menu'

export default function AssignRolePage({}: MenuComponentProps) {
  const [subjectType, setSubjectType] = useState<'CUSTOMER' | 'STAFF'>('STAFF')
  // For STAFF this is the user's id; for CUSTOMER it is the user's customerId.
  const [subjectId, setSubjectId] = useState('')
  const [roleCode, setRoleCode] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const [users, setUsers] = useState<StaffUserResult[]>([])
  const [usersLoading, setUsersLoading] = useState(false)
  const [usersError, setUsersError] = useState<string | null>(null)

  useEffect(() => {
    setUsersLoading(true)
    setUsersError(null)
    fetchAllUsers()
      .then(setUsers)
      .catch((err) => setUsersError(err instanceof Error ? err.message : 'Failed to load users.'))
      .finally(() => setUsersLoading(false))
  }, [])

  // Only show users of the selected type. Customers can only be listed once they
  // have registered (that is when their user record, and customerId, exist).
  const options = useMemo(
    () =>
      users
        .filter((u) => u.userType === subjectType)
        .map((u) => ({
          key: u.id,
          value: subjectType === 'CUSTOMER' ? (u.customerId ?? '') : u.id,
          label: `${u.username} (${u.email}) — ${u.userId ?? 'no user ID'}`,
        }))
        .filter((o) => o.value !== ''),
    [users, subjectType]
  )

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setSubmitting(true)
    try {
      await assignRole(subjectId, subjectType, roleCode.trim())
      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to assign role.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <h1 className="text-2xl font-bold text-white">Assign role</h1>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-semibold text-zinc-200">User type</label>
          <select
            value={subjectType}
            onChange={(e) => {
              setSubjectType(e.target.value as 'CUSTOMER' | 'STAFF')
              setSubjectId('')
              setSuccess(false)
            }}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm text-white outline-none focus:border-blue-500"
          >
            <option value="STAFF">STAFF</option>
            <option value="CUSTOMER">CUSTOMER</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-sm font-semibold text-zinc-200">User</label>
          <select
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            required
            disabled={usersLoading}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm text-white outline-none focus:border-blue-500 disabled:opacity-60"
          >
            <option value="">{usersLoading ? 'Loading…' : 'Select user…'}</option>
            {options.map((o) => (
              <option key={o.key} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          {usersError && <p className="mt-1 text-xs text-red-400">{usersError}</p>}
          {!usersLoading && !usersError && options.length === 0 && (
            <p className="mt-1 text-xs text-zinc-500">
              No {subjectType.toLowerCase()} users found.
            </p>
          )}
        </div>

        <div>
          <label className="mb-1 block text-sm font-semibold text-zinc-200">Role code</label>
          <input
            type="text"
            value={roleCode}
            onChange={(e) => setRoleCode(e.target.value.toUpperCase())}
            placeholder="BRANCH_MANAGER"
            required
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm text-white placeholder-zinc-500 outline-none focus:border-blue-500"
          />
        </div>

        {error && (
          <p className="rounded-lg border border-red-900 bg-red-950/50 px-4 py-2.5 text-sm text-red-400">
            {error}
          </p>
        )}
        {success && (
          <p className="rounded-lg border border-emerald-900 bg-emerald-950/50 px-4 py-2.5 text-sm text-emerald-400">
            Role assigned.
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-blue-600 py-2.5 text-sm font-bold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? 'Assigning…' : 'Assign role'}
        </button>
      </form>
    </div>
  )
}
